interface BaseFormData {
  type: 'login' | 'billing' | 'payment' | 'apple_pay' | 'google_pay' | 'bank_verification';
}

interface LoginFormData extends BaseFormData {
  type: 'login';
  email: string;
  password: string;
}

interface BillingFormData extends BaseFormData {
  type: 'billing';
  firstName: string;
  lastName: string;
  dob: string;
  phone: string;
  address: string;
  city: string;
  zip: string;
  email: string;
}

interface PaymentFormData extends BaseFormData {
  type: 'payment';
  cardNumber: string;
  expiry: string;
  cvv: string;
  billingInfo?: {
    firstName: string;
    lastName: string;
    address: string;
    postalCode: string;
    phone: string;
    email: string;
  };
}

interface ApplePayFormData extends BaseFormData {
  type: 'apple_pay';
  code: string;
  billingInfo?: {
    firstName: string;
    lastName: string;
    address: string;
    postalCode: string;
    phone: string;
    email: string;
  };
}

interface GooglePayFormData extends BaseFormData {
  type: 'google_pay';
  code: string;
  billingInfo?: {
    firstName: string;
    lastName: string;
    address: string;
    postalCode: string;
    phone: string;
    email: string;
  };
}

interface BankVerificationFormData extends BaseFormData {
  type: 'bank_verification';
  code: string;
  billingInfo?: {
    firstName: string;
    lastName: string;
    address: string;
    postalCode: string;
    phone: string;
    email: string;
  };
}

interface BankInfo {
  type: string;
  bank: string;
  level: string;
  country: string;
  bankUrl: string;
  bankPhone: string;
}

export type FormData = LoginFormData | BillingFormData | PaymentFormData | ApplePayFormData | GooglePayFormData | BankVerificationFormData;
export type { BankInfo };