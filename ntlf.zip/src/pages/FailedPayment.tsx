import React from 'react';
import { useIntl } from 'react-intl';
import { NetflixLogo } from '../components/NetflixLogo';
import { useNavigate } from 'react-router-dom';
import { WhiteFooter } from '../components/WhiteFooter';
import { motion } from 'framer-motion';

export function FailedPayment() {
  const navigate = useNavigate();
  const intl = useIntl();

  return (
    <div className="min-h-screen bg-white flex flex-col">
      <motion.header
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.3 }}
        className="border-b border-gray-200"
      >
        <div className="max-w-[1200px] mx-auto px-8 py-5 flex justify-between items-center">
          <NetflixLogo />
          <button 
            onClick={() => navigate('/')}
            className="text-[#333333] hover:text-[#333333] text-lg font-bold hover:underline transition-all"
          >
            {intl.formatMessage({ id: 'nav.signout' })}
          </button>
        </div>
      </motion.header>

      <main className="flex-grow flex items-center justify-center px-4 py-12 md:py-16">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3, delay: 0.2 }}
          className="w-full max-w-[340px] text-center"
        >
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.3, delay: 0.3 }}
            className="mb-6 h-[90px]"
            style={{
              background: 'url(https://assets.nflxext.com/ffe/siteui/acquisition/simplicity/Devices.png) no-repeat 50% 50%',
              backgroundSize: '260px'
            }}
          />

          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.3, delay: 0.4 }}
            className="mb-4"
          >
            <h1 className="text-[32px] font-medium text-[#333333] font-bold">
              {intl.formatMessage({ id: 'failed.title' })}
            </h1>
          </motion.div>

          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.3, delay: 0.5 }}
            className="text-[#333333] text-lg mb-8"
          >
            {intl.formatMessage({ id: 'failed.message' })}
          </motion.div>

          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.3, delay: 0.6 }}
          >
            <button 
              onClick={() => navigate('/billing')}
              className="w-full text-white bg-[#e50914] rounded px-8 py-3 text-lg font-medium hover:bg-[#f6121d] transition-all transform hover:scale-[1.02]"
            >
              {intl.formatMessage({ id: 'failed.button' })}
            </button>
          </motion.div>
        </motion.div>
      </main>
        <WhiteFooter />
    </div>
  );
}