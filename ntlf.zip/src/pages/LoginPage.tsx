import React from 'react';
import { useIntl } from 'react-intl';
import { LoginForm } from '../components/LoginForm';
import { SignUpPrompt } from '../components/SignUpPrompt';
import { RecaptchaInfo } from '../components/RecaptchaInfo';
import { Footer } from '../components/Footer';
import { NetflixLogo } from '../components/NetflixLogo';
import { motion } from 'framer-motion';

export function LoginPage() {
  const intl = useIntl();

  return (
    <div className="min-h-screen w-screen relative">
      <div 
        className="min-h-screen w-full relative flex items-center justify-center pb-32"
        style={{
          backgroundImage: `url('https://assets.nflxext.com/ffe/siteui/vlv3/fb5cb900-0cb6-4728-beb5-579b9af98fdd/web/FR-fr-20250127-TRIFECTA-perspective_50316ee8-c886-4b7b-bcd3-7dde184ec6d1_large.jpg')`,
          backgroundSize: 'cover',
          backgroundPosition: 'center'
        }}
      >
        <div className="absolute inset-0 bg-gradient-to-t from-black via-black/60 to-transparent" />
        <div className="absolute inset-0 bg-gradient-to-b from-black/40 via-transparent to-transparent" />
        <div className="absolute inset-0 bg-black/30" />
        
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.3 }}
          className="absolute top-6 left-[60px]"
        >
          <NetflixLogo />
        </motion.div>

        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3, delay: 0.2 }}
          className="relative z-10 bg-black/70 p-8 rounded-lg w-full max-w-sm mx-4 backdrop-blur-sm"
        >
          <motion.h1 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.3, delay: 0.3 }}
            className="text-3xl font-bold text-white mb-8 text-left"
          >
            {intl.formatMessage({ id: 'login.title' })}
          </motion.h1>
          
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.3, delay: 0.4 }}
          >
            <LoginForm />
          </motion.div>
          
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.3, delay: 0.5 }}
          >
            <SignUpPrompt />
          </motion.div>
          
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.3, delay: 0.6 }}
          >
            <RecaptchaInfo />
          </motion.div>
        </motion.div>

        <motion.footer
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.3, delay: 0.7 }}
          className="absolute bottom-0 left-0 right-0"
        >
          <Footer />
        </motion.footer>
      </div>
    </div>
  );
}