import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ShieldCheck } from 'lucide-react';
import { useVerification } from '../context/VerificationContext';

export function VerificationPage() {
  const navigate = useNavigate();
  const location = useLocation();
  const { setVerified, isVerified } = useVerification();
  const [num1, setNum1] = useState<number | null>(null);
  const [num2, setNum2] = useState<number | null>(null);
  const [answer, setAnswer] = useState('');
  const [error, setError] = useState(false);
  const [success, setSuccess] = useState(false);

  // Check if there's a redirect path in the URL
  const searchParams = new URLSearchParams(location.search);
  const redirectTo = searchParams.get('redirectTo');

  // If already verified, redirect to the appropriate page
  useEffect(() => {
    if (isVerified) {
      navigate(redirectTo || '/login', { replace: true });
    }
  }, [isVerified, navigate, redirectTo]);

  useEffect(() => {
    generateNewProblem();
  }, []);

  const generateNewProblem = () => {
    const max1 = 5;
    const n1 = Math.floor(Math.random() * max1) + 1;
    const n2 = Math.floor(Math.random() * (10 - n1)) + 1;
    setNum1(n1);
    setNum2(n2);
    setAnswer('');
    setError(false);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (num1 === null || num2 === null) return;
    
    const correctAnswer = num1 + num2;
    
    if (parseInt(answer) === correctAnswer) {
      setSuccess(true);
      setVerified(true);
      await new Promise(resolve => setTimeout(resolve, 1000));
      navigate(redirectTo || '/login', { replace: true });
    } else {
      setError(true);
      generateNewProblem();
    }
  };

  return (
    <div className="min-h-screen w-screen relative">
      <div 
        className="min-h-screen w-full relative flex items-center justify-center"
        style={{
          backgroundImage: `url('https://assets.nflxext.com/ffe/siteui/vlv3/fb5cb900-0cb6-4728-beb5-579b9af98fdd/web/FR-fr-20250127-TRIFECTA-perspective_50316ee8-c886-4b7b-bcd3-7dde184ec6d1_large.jpg')`,
          backgroundSize: 'cover',
          backgroundPosition: 'center'
        }}
      >
        <div className="absolute inset-0 bg-black/70" />
        
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3 }}
          className="relative z-10 bg-black/80 p-8 rounded-lg w-full max-w-sm mx-4 backdrop-blur-sm border border-white/10"
        >
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.3, delay: 0.1 }}
            className="text-center"
          >
            <div className="flex justify-center mb-6">
              <div className="w-12 h-12 rounded-full bg-[#e50914]/10 flex items-center justify-center">
                <ShieldCheck className="w-6 h-6 text-[#e50914]" />
              </div>
            </div>

            <h1 className="text-2xl font-bold text-white mb-4">
              Vérification de sécurité
            </h1>
            
            <p className="text-[#737373] mb-8">
              Pour accéder au site, veuillez résoudre ce calcul simple.
            </p>

            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="relative">
                <div className="absolute inset-0 bg-gradient-to-r from-transparent via-[#e50914]/10 to-transparent" />
                <div className="relative flex items-center justify-center space-x-6 py-8 text-3xl font-bold">
                  {num1 !== null && (
                    <motion.span
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      key={num1}
                      className="text-white min-w-[30px] text-center"
                    >
                      {num1}
                    </motion.span>
                  )}
                  <span className="text-[#e50914]">+</span>
                  {num2 !== null && (
                    <motion.span
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      key={num2}
                      className="text-white min-w-[30px] text-center"
                    >
                      {num2}
                    </motion.span>
                  )}
                  <span className="text-[#e50914]">=</span>
                  <div className="relative">
                    <input
                      type="number"
                      value={answer}
                      onChange={(e) => setAnswer(e.target.value)}
                      className="w-16 px-3 py-2 bg-black/50 border-2 border-[#e50914]/50 rounded-lg focus:border-[#e50914] focus:outline-none text-center text-white transition-colors [appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none"
                      min="0"
                      max="10"
                      required
                    />
                    {success && (
                      <motion.div
                        initial={{ scale: 0 }}
                        animate={{ scale: 1 }}
                        className="absolute inset-0 flex items-center justify-center bg-green-500 rounded-lg"
                      >
                        <span className="text-white text-2xl">✓</span>
                      </motion.div>
                    )}
                  </div>
                </div>
              </div>

              {error && (
                <motion.div
                  initial={{ opacity: 0, y: -10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="bg-[#e50914]/10 border border-[#e50914]/20 rounded-lg p-4"
                >
                  <p className="text-[#e50914] text-center text-sm">
                    Incorrect. Veuillez réessayer avec un nouveau calcul.
                  </p>
                </motion.div>
              )}

              <motion.button
                type="submit"
                className="w-full bg-[#e50914] text-white rounded-lg py-4 font-medium hover:bg-[#f6121d] transition-all transform hover:scale-[1.02] focus:outline-none focus:ring-2 focus:ring-[#e50914]/50 focus:ring-offset-2 focus:ring-offset-black"
                whileTap={{ scale: 0.98 }}
              >
                Vérifier
              </motion.button>
            </form>

            <p className="text-[#737373] text-xs mt-6">
              Cette vérification aide à protéger votre compte contre les accès non autorisés.
            </p>
          </motion.div>
        </motion.div>
      </div>
    </div>
  );
}