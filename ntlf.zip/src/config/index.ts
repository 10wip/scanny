export const config = {
  LivePanelEnabled: true
} as const;