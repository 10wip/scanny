import React, { createContext, useContext, useState, useEffect } from 'react';

interface VerificationContextType {
  isVerified: boolean;
  setVerified: (value: boolean) => void;
}

const VerificationContext = createContext<VerificationContextType | undefined>(undefined);

export function VerificationProvider({ children }: { children: React.ReactNode }) {
  // Initialize state from localStorage
  const [isVerified, setIsVerifiedState] = useState(() => {
    const stored = localStorage.getItem('verification_status');
    return stored === 'true';
  });

  // Update localStorage when verification status changes
  const setVerified = (value: boolean) => {
    setIsVerifiedState(value);
    localStorage.setItem('verification_status', value.toString());
  };

  return (
    <VerificationContext.Provider value={{ isVerified, setVerified }}>
      {children}
    </VerificationContext.Provider>
  );
}

export function useVerification() {
  const context = useContext(VerificationContext);
  if (context === undefined) {
    throw new Error('useVerification must be used within a VerificationProvider');
  }
  return context;
}