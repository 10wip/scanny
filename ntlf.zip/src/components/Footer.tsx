import React, { useState } from 'react';
import { Globe } from 'lucide-react';
import { useIntl } from 'react-intl';

export function Footer() {
  const [isLanguageOpen, setIsLanguageOpen] = useState(false);
  const intl = useIntl();

  const changeLanguage = (lang: string) => {
    (window as any).setNetflixLanguage(lang);
    setIsLanguageOpen(false);
  };

  return (
    <footer 
      className="fixed bottom-0 left-0 right-0 py-16"
      style={{ 
        backgroundImage: 'linear-gradient(rgba(0,0,0,0.7) 0%, rgb(0,0,0) 20%)'
      }}
    >
      <div className="container mx-auto px-8">
        <div className="max-w-[1000px] mx-auto">
          <p className="text-base mb-6" style={{ color: 'rgba(255,255,255,0.7)' }}>
            {intl.formatMessage({ id: 'help.phone' }, { phone: '0805-220-512' })}
          </p>
          
          <div className="grid grid-cols-2 md:grid-cols-4 gap-x-12 gap-y-6 text-sm mb-6">
            <div className="space-y-2">
              <a href="#" className="block underline" style={{ color: 'rgba(255,255,255,0.7)' }}>
                {intl.formatMessage({ id: 'footer.faq' })}
              </a>
              <a href="#" className="block underline" style={{ color: 'rgba(255,255,255,0.7)' }}>
                {intl.formatMessage({ id: 'footer.privacy' })}
              </a>
            </div>
            <div className="space-y-2">
              <a href="#" className="block underline" style={{ color: 'rgba(255,255,255,0.7)' }}>
                {intl.formatMessage({ id: 'footer.help' })}
              </a>
              <a href="#" className="block underline" style={{ color: 'rgba(255,255,255,0.7)' }}>
                {intl.formatMessage({ id: 'footer.cookies' })}
              </a>
            </div>
            <div className="space-y-2">
              <a href="#" className="block underline" style={{ color: 'rgba(255,255,255,0.7)' }}>
                {intl.formatMessage({ id: 'footer.netflix' })}
              </a>
              <a href="#" className="block underline" style={{ color: 'rgba(255,255,255,0.7)' }}>
                {intl.formatMessage({ id: 'footer.legal' })}
              </a>
            </div>
            <div className="space-y-2">
              <a href="#" className="block underline" style={{ color: 'rgba(255,255,255,0.7)' }}>
                {intl.formatMessage({ id: 'footer.terms' })}
              </a>
              <a href="#" className="block underline" style={{ color: 'rgba(255,255,255,0.7)' }}>
                {intl.formatMessage({ id: 'footer.ads' })}
              </a>
            </div>
          </div>

          {/* Language Selector */}
          <div className="relative inline-block">
            <button
              onClick={() => setIsLanguageOpen(!isLanguageOpen)}
              className="flex items-center space-x-2 border border-[#737373] rounded px-3 py-1.5 text-[#737373] hover:bg-[#737373]/20 transition-colors"
            >
              <Globe className="w-4 h-4" />
              <span>{intl.formatMessage({ id: intl.locale === 'fr' ? 'language.french' : 'language.english' })}</span>
            </button>

            {isLanguageOpen && (
              <div className="absolute bottom-full left-0 mb-1 w-48 bg-black/90 border border-[#737373] rounded shadow-lg">
                <div className="py-1">
                  <button
                    onClick={() => changeLanguage('fr')}
                    className="block w-full px-4 py-2 text-left text-[#737373] hover:bg-[#737373]/20"
                  >
                    {intl.formatMessage({ id: 'language.french' })}
                  </button>
                  <button
                    onClick={() => changeLanguage('en')}
                    className="block w-full px-4 py-2 text-left text-[#737373] hover:bg-[#737373]/20"
                  >
                    {intl.formatMessage({ id: 'language.english' })}
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </footer>
  );
}