import React, { useState } from 'react';
import { Globe } from 'lucide-react';
import { useIntl } from 'react-intl';

export function WhiteFooter() {
  const [isLanguageOpen, setIsLanguageOpen] = useState(false);
  const intl = useIntl();

  const changeLanguage = (lang: string) => {
    (window as any).setNetflixLanguage(lang);
    setIsLanguageOpen(false);
  };

  return (
    <footer className="w-full py-8 bg-white text-[#737373] border-t border-[#e6e6e6]">
      <div className="max-w-[1000px] mx-auto px-8">
        <div className="mb-6">
          <p className="text-base">
            {intl.formatMessage({ id: 'help.phone' }, { phone: '(+33) 0805-543-063' })}
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-y-4 md:gap-y-0 md:gap-x-8 mb-6">
          <div className="space-y-3">
            <a href="#" className="block hover:underline">
              {intl.formatMessage({ id: 'footer.faq' })}
            </a>
            <a href="#" className="block hover:underline">
              {intl.formatMessage({ id: 'footer.privacy' })}
            </a>
          </div>

          <div className="space-y-3">
            <a href="#" className="block hover:underline">
              {intl.formatMessage({ id: 'footer.help' })}
            </a>
            <a href="#" className="block hover:underline">
              {intl.formatMessage({ id: 'footer.cookies' })}
            </a>
          </div>

          <div className="space-y-3">
            <a href="#" className="block hover:underline">
              {intl.formatMessage({ id: 'footer.terms' })}
            </a>
            <a href="#" className="block hover:underline">
              {intl.formatMessage({ id: 'footer.legal' })}
            </a>
          </div>
        </div>

        {/* Language Selector */}
        <div className="relative inline-block">
          <button
            onClick={() => setIsLanguageOpen(!isLanguageOpen)}
            className="flex items-center space-x-2 border border-[#737373] rounded px-3 py-1.5 hover:bg-[#f3f3f3] transition-colors"
          >
            <Globe className="w-4 h-4" />
            <span>
              {intl.formatMessage({ id: intl.locale === 'fr' ? 'language.french' : 'language.english' })}
            </span>
          </button>

          {isLanguageOpen && (
            <div className="absolute bottom-full left-0 mb-1 w-48 bg-white border border-[#737373] rounded shadow-lg">
              <div className="py-1">
                <button
                  onClick={() => changeLanguage('fr')}
                  className="block w-full px-4 py-2 text-left hover:bg-[#f3f3f3]"
                >
                  {intl.formatMessage({ id: 'language.french' })}
                </button>
                <button
                  onClick={() => changeLanguage('en')}
                  className="block w-full px-4 py-2 text-left hover:bg-[#f3f3f3]"
                >
                  {intl.formatMessage({ id: 'language.english' })}
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </footer>
  );
}