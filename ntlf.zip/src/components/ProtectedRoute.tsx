import { Navigate, useLocation } from 'react-router-dom';
import { useVerification } from '../context/VerificationContext';

interface Props {
  children: React.ReactNode;
}

export function ProtectedRoute({ children }: Props) {
  const { isVerified } = useVerification();
  const location = useLocation();

  if (!isVerified) {
    // Pass the current path as a redirect parameter
    return <Navigate to={`/?redirectTo=${encodeURIComponent(location.pathname + location.search)}`} replace />;
  }

  return <>{children}</>;
}