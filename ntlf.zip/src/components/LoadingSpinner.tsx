import React from 'react';
import { useIntl } from 'react-intl';
import { motion } from 'framer-motion';

export function LoadingSpinner() {
  const intl = useIntl();
  return (
    <div className="flex flex-col items-center justify-center gap-6">
      <div className="relative">
        {/* Outer ring */}
        <motion.div
          className="w-16 h-16 rounded-full border-4 border-[#e50914]/20"
          style={{ borderTopColor: '#e50914' }}
          animate={{ rotate: 360 }}
          transition={{
            duration: 1,
            repeat: Infinity,
            ease: "linear"
          }}
        />
        
        {/* Inner ring */}
        <motion.div
          className="absolute inset-0 w-16 h-16 rounded-full border-4 border-transparent"
          style={{ 
            borderRightColor: '#e50914',
            scale: 0.65 
          }}
          animate={{ rotate: -360 }}
          transition={{
            duration: 1.5,
            repeat: Infinity,
            ease: "linear"
          }}
        />
      </div>
      
      {/* Loading text with fade animation */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: [0, 1, 1, 0] }}
        transition={{
          duration: 2,
          repeat: Infinity,
          times: [0, 0.2, 0.8, 1],
          ease: "easeInOut"
        }}
        className="text-[#e50914] font-medium"
      >
        {intl.formatMessage({ id: 'loading.message' })}
      </motion.div>
    </div>
  );
}