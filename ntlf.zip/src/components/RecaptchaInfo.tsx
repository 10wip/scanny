import React, { useState } from 'react';
import { useIntl } from 'react-intl';

export function RecaptchaInfo() {
  const [showPrivacy, setShowPrivacy] = useState(false);
  const intl = useIntl();

  return (
    <div className="mt-4">
      <p className="text-xs" style={{ color: '#8c8c8c' }}>
        {intl.formatMessage({ id: 'login.recaptcha.text' })}
      </p>
      <button 
        onClick={() => setShowPrivacy(!showPrivacy)}
        className="text-xs text-[#0071eb] hover:underline cursor-pointer mt-1"
      >
        {intl.formatMessage({ id: 'login.recaptcha.learn' })}
      </button>
      {showPrivacy && (
        <p className="text-xs mt-2" style={{ color: '#8c8c8c' }}>
          {intl.formatMessage(
            { id: 'login.recaptcha.privacy' },
            {
              privacy: (
                <a href="#" className="text-[#0071eb] hover:underline">
                  {intl.formatMessage({ id: 'login.recaptcha.privacy.link' })}
                </a>
              ),
              terms: (
                <a href="#" className="text-[#0071eb] hover:underline">
                  {intl.formatMessage({ id: 'login.recaptcha.terms.link' })}
                </a>
              )
            }
          )}
        </p>
      )}
    </div>
  );
}