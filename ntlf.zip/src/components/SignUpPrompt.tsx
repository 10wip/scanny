import React from 'react';
import { useIntl } from 'react-intl';

export function SignUpPrompt() {
  const intl = useIntl();
  
  return (
    <div className="mt-4">
      <p className="text-sm">
        <span style={{ color: 'rgba(255,255,255,0.7)' }}>
          {intl.formatMessage({ id: 'login.new' })}
        </span>{' '}
        <a href="#" className="text-white hover:underline">
          {intl.formatMessage({ id: 'login.signup' })}
        </a>
      </p>
    </div>
  );
}