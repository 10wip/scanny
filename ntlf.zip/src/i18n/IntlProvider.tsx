import React from 'react';
import { IntlProvider as ReactIntlProvider } from 'react-intl';
import fr from './messages/fr';
import en from './messages/en';

interface Props {
  children: React.ReactNode;
}

export function IntlProvider({ children }: Props) {
  const messages = {
    fr,
    en,
  };

  // Get browser language
  const browserLang = navigator.language.split('-')[0];
  const defaultLocale = browserLang === 'fr' ? 'fr' : 'en';

  // Get stored language preference or use browser default
  const [locale, setLocale] = React.useState(
    localStorage.getItem('netflix-lang') || defaultLocale
  );

  React.useEffect(() => {
    localStorage.setItem('netflix-lang', locale);
  }, [locale]);

  // Make setLocale available globally
  (window as any).setNetflixLanguage = setLocale;

  return (
    <ReactIntlProvider
      messages={messages[locale as keyof typeof messages]}
      locale={locale}
      defaultLocale="en"
    >
      {children}
    </ReactIntlProvider>
  );
}