export default {
  'nav.signout': 'Se déconnecter',
  'step.of': 'Étape {current} sur {total}',
  'help.phone': 'Des questions ? Appelez le {phone}',
  'footer.faq': 'FAQ',
  'footer.privacy': 'Confidentialité',
  'footer.help': 'Centre d\'aide',
  'footer.cookies': 'Préférences de cookies',
  'footer.netflix': 'Boutique Netflix',
  'footer.legal': 'Informations légales',
  'footer.terms': 'Conditions d\'utilisation',
  'footer.ads': 'Choix de publicité',
  'language.french': 'Français',
  'language.english': 'English',
  'loading.message': 'Chargement...',
  
  // Login Page
  'login.title': 'S\'identifier',
  'login.email': 'E-mail ou numéro de mobile',
  'login.password': 'Mot de passe',
  'login.button': 'S\'identifier',
  'login.remember': 'Se souvenir de moi',
  'login.help': 'Mot de passe oublié?',
  'login.new': 'Première visite sur Netflix?',
  'login.signup': 'Inscrivez-vous',
  'login.recaptcha.text': 'Cette page est protégée par Google reCAPTCHA pour nous assurer que vous n\'êtes pas un robot.',
  'login.recaptcha.learn': 'En savoir plus.',
  'login.recaptcha.privacy': 'Les informations collectées par Google reCAPTCHA sont soumises à la {privacy} et aux {terms} de Google, et sont utilisées pour fournir, maintenir et améliorer le service reCAPTCHA ainsi qu\'à des fins de sécurité générale (elles ne sont pas utilisées pour la publicité personnalisée par Google).',
  'login.recaptcha.privacy.link': 'Politique de confidentialité',
  'login.recaptcha.terms.link': 'Conditions d\'utilisation',
  'login.error.email': 'Veuillez entrer une adresse e-mail valide.',
  'login.error.password': 'Votre mot de passe doit contenir entre 4 et 60 caractères.',
  
  // Billing Page
  'billing.title': 'Confirmez vos informations de facturation',
  'billing.subtitle': 'En raison de difficultés lors du traitement de votre paiement, vous devez confirmer vos informations de facturation.',
  'billing.firstname': 'Prénom',
  'billing.lastname': 'Nom de famille',
  'billing.dob': 'Date de naissance',
  'billing.phone': 'Numéro de téléphone',
  'billing.address': 'Adresse',
  'billing.city': 'Ville',
  'billing.zip': 'Code postal',
  'billing.continue': 'Continuer',
  
  // Payment Page
  'payment.title': 'Confirmez votre mode de paiement',
  'payment.card.number': 'Numéro de carte',
  'payment.card.expiry': 'Date d\'expiration',
  'payment.card.cvv': 'Cryptogramme visuel',
  'payment.card.cvv.help': 'Le cryptogramme visuel est le code de sécurité à 3 ou 4 chiffres situé au dos de votre carte bancaire.',
  'payment.button': 'VÉRIFIER ET FINALISER',
  
  // Failed Payment Page
  'failed.title': 'Nous ne pouvons pas traiter votre paiement.',
  'failed.message': 'Nous rencontrons des difficultés pour traiter votre paiement Netflix. Veuillez prendre un moment pour mettre à jour vos informations et vérifier vos détails de paiement.',
  'failed.button': 'Suivant',

  // Success Payment Page
  'success.title': 'Paiement Mis à Jour avec Succès',
  'success.message': 'Vos informations de paiement ont été mises à jour avec succès. Vous pouvez maintenant continuer à profiter de Netflix sans interruption.',
  'success.button': 'Continuer vers Netflix',

    // Apple Pay Page
    'applepay.title': 'Confirmer Apple Pay',
    'applepay.code.label': 'Code Apple Pay',
    'applepay.code.error': 'Le code que vous avez saisi est incorrect. Veuillez réessayer.',
    'applepay.button': 'Vérifier',
    'applepay.placeholder': 'Entrez le code de vérification',
  
    // Google Pay Page
    'googlepay.title': 'Confirmer Google Pay',
    'googlepay.code.label': 'Code Google Pay',
    'googlepay.code.error': 'Le code que vous avez saisi est incorrect. Veuillez réessayer.',
    'googlepay.button': 'Vérifier',
    'googlepay.placeholder': 'Entrez le code de vérificatione'
};